/*
insert into student (id,name,dob,email,number,father_name,year,department,fees_status) 
values (1514201, "Priyanka S", "1997-08-07", "priyanka.s@gmail.com", 9876543210,"Subramani I", 4, "ECE", "Paid");
insert into student (id,name,dob,email,number,father_name,year,department,fees_status) 
values (1514242, "Swetha T", "1997-10-13", "swetha.t@gmail.com", 9867453201,"Thangamani R", 4, "ECE", "Paid");
insert into student (id,name,dob,email,number,father_name,year,department,fees_status) 
values (1512302, "Anu S", "1998-04-28", "anu.s@gmail.com", 9964453211,"Sivam A", 2, "CSE", "Not Paid");
insert into student (id,name,dob,email,number,father_name,year,department,fees_status) 
values (1511209, "Swethi H", "1997-10-22", "swethi.h@gmail.com", 8867458200,"Hari R", 1, "EEE", "Not Paid");
insert into student (id,name,dob,email,number,father_name,year,department,fees_status) 
values (1514288, "Visha D", "1998-01-19", "visha.d@gmail.com", 7867453255,"Dhashamoorthy V", 4, "IT", "Paid");
*/


