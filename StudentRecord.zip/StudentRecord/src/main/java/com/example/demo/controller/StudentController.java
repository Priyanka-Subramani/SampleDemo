package com.example.demo.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Student;
import com.example.demo.service.StudentService;

@RestController
public class StudentController {
	
	@Autowired
	StudentService studentService;
	
	
	@GetMapping("/home")
	public String home() {
		return "Welcome to Student Details";
	}
	
	//Creating a get mapping that retrieves all the Students details from the Database
	@GetMapping("/students")
	public List<Student> getAllStudents(Student student) {
		return studentService.getAllStudets(student);
	}
	
	//Creating a get mapping that retrieves the details of a specific Student
	@GetMapping("/student/{id}")
	public Optional<Student> getStudent(@PathVariable("id") int id) {
		return studentService.getStudent(id);
	}
	
	//Creating a get mapping that retrieves students details of a specific department
	@GetMapping("/studentss/{dept}")
	public List<Student> getStudentsByDepartment(@PathVariable("dept") String department) {
		return studentService.findByDepartment(department);
	}
	
	//Creating a get mapping that retrieves students details of a specific Year
	@GetMapping("/students/{year}")
	public List<Student> getStudentsByYear(@PathVariable("year") int year) {
		return studentService.findByYear(year);
	}
	
	//Creating a post mapping that post/save the Student detail in the database 
	@PostMapping("/students")
	public Student addStudent(@RequestBody Student student) {
		return studentService.addStudent(student);
	}
	
	//Creating a delete mapping that deletes a specified Student
	@DeleteMapping("/student/{id}")
	public String deleteStudent(@PathVariable("id") int id) {
		studentService.deleteStudent(id);
		return "Deleted";
	}
	
	//Creating a put mapping that updates the Student detail
	@PutMapping("/students") 
	public Student saveOrUpdateStudent(@RequestBody Student student) {
		return studentService.saveorUpdateStudent(student);
	}

}
