package com.example.demo.service;

import java.util.List;
import java.util.Optional;
import com.example.demo.model.Student;


public interface StudentService {
	
	public List<Student> getAllStudets(Student student);
	
	public Optional<Student> getStudent(int id);
	
    public List<Student> findByDepartment(String department);
	
	public List<Student> findByYear(int year);
	
	public Student addStudent(Student student);
	
	public String deleteStudent(int id);
	
	public Student saveorUpdateStudent(Student student);

}
